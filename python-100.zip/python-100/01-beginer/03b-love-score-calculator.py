# Love Score Calculator
# Returning Love Score based on full names

print("Welcome to the Love Score Calculator.")

name_1 = input("What is your name? ").lower()
name_2 = input("What is their name? ").lower()

name = name_1 + name_2

t_count = name.count("t")
r_count = name.count("r")
u_count = name.count("u")
e_count = name.count("e")
total_true = t_count + r_count + u_count + e_count

l_count = name.count("l")
o_count = name.count("o")
v_count = name.count("v")
total_love = l_count + o_count + v_count + e_count

print(f"T count is : {t_count}")
print(f"R count is : {r_count}")
print(f"U count is : {u_count}")
print(f"E count is : {e_count}")
print(f"TRUE count is : {total_true}")


print(f"L count is : {l_count}")
print(f"O count is : {o_count}")
print(f"V count is : {v_count}")
print(f"E count is : {e_count}")
print(f"LOVE count is : {total_love}")

score = int(str(total_true) + str(total_love))

if score <= 10 or score >= 90:
    print(f"Your score is {score}, you go together like coke and mentos.")
elif score >= 40 and score <= 50:
    print(f"Your score is {score}, you alright together.")
else:
    print(f"Your score is {score}")

