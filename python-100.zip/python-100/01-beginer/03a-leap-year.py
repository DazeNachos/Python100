# Leap Year Calculator
# Returning if a particular year is a leap year or not

print("Welcome to the Lear Year Calculator.")

year = int(input("Which year do you want to check? "))

leap_year = False
reason = ""

if year % 4 == 0:
    if year % 100 == 0:
        if year % 400 == 0:
            leap_year = True
            reason="divisible by 4, but also divisible by 100, however also divisible by 400"
        else:
            leap_year = False
            reason="divisible by 4, but also divisible by 100"
    else:
        leap_year = True
        reason="divisible by 4"
else:
    leap_year = False
    reason="not divisible by 4"


if leap_year:
    print(f"Year {year} is a leap year: {reason}")
else:
    print(f"Year {year} is NOT a leap year: {reason}")