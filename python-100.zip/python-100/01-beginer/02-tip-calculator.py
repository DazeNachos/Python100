# Tip Calculator
# dividing equally the bill between people considering tip

print("Welcome to the Tip Calculator.")

total_bill = float(input("What was the total bill? $"))

percent_tip = int(input("What the percentage tip would you like to give? 10, 12 or 15? "))

number_person = int(input("How many people to split the bill? "))

bill_per_person = ( total_bill * ( 1 + percent_tip / 100 ) ) / number_person

formated_bill_per_person = "{:.2f}".format(round(bill_per_person, 2))

# print(f"Each person should pay: ${round(bill_per_person, 2)}")

print(f"Each person should pay: ${formated_bill_per_person}")