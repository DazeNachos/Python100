# Treasure Game
# Little game based on character choice

print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/______/_
*******************************************************************************
''')

print("Welcome to the Treasure Island.")
print("Your mission is to find the treasure.")

choice1 = input("You are at a cross-road, where do you want to go? right or left?\n")

if (choice1.lower() == "right"):
    
    choice2 = input("You arrive to a lake. Type 'wait' to wait for a boat or 'swim' to swim accross.\n")

    if choice2.lower() == "wait":

        choice3 = input("You arrive at the island unharmed, there is a house with 3 doors. One red, one blue and one yellow. Which color do you use?\n")

        if choice3.lower() == "red":
            print("You enter in the room del infierno... Game Over...")
        elif choice3.lower() == "blue":
            print("You enter a room full of insects... Game Over...")
        else:
            print("You enter a room full of light, and at the corner there is the treasure! Congrats!")
    else:
        print("There was sharks into the lake... Game Over...")
else:
    print("You fell into a hole... Game Over...")